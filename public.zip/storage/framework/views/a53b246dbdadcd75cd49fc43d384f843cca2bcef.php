<?php $__env->startSection('title'); ?>
Quicker
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-class'); ?>
class="cutsom-scroll"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-class'); ?>
d-none
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form id="formSubcategories" method="POST" action="<?php echo e(url('quote/'.$category_id.'/step-1')); ?>"> 
<?php echo csrf_field(); ?>
<main>
    <div class="container margin_60_35"  style="padding-top: 30px;">
        <h6 class="mt-2 quote-title">What service do you need?</h6>
        <div class="row mt-3 mb-5">
            <div class="col-12">
            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group checkbox-label-card">
                    <label class="container_check checkbox-label"> <?php echo e($category->name); ?>

                        <input type="checkbox" name="sub_categories[<?php echo e($key); ?>]" value="<?php echo e($category->id); ?>">
                        <span class="checkmark"></span>
                    </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>    
    </div>
<!-- /container -->
</main>
<div class="snackbar"></div>
<nav class="navbar fixed-bottom bg-white">
    <div class="container text-center">
        <button onclick="validateForm();" type="button" class="btn btn-primary btn-block">Get Started <i class="icon-angle-right"></i></button>
    </div>
</nav>


</form>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-class'); ?>
d-none
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modals'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
function validateForm(){
 checked = $("input[type=checkbox]:checked").length;
  if(!checked){
    $(".snackbar").addClass('show');
    $(".snackbar").text("You must check at least one checkbox.");
    return false;
  }else{
    $(".snackbar").removeClass('show');
    $("#formSubcategories").submit();
  }
}
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>