<?php $__env->startSection('title'); ?>
Dashboard | Quicker
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="results" style="padding: 10px 0;">
       <div class="container">
           <div class="row">
               <div class="col-lg-3 col-md-4 col-10 d-none d-lg-block">
                   <h4 style="font-size: 18px;">Jobs</h4>
               </div>
               <div class="col-lg-9 quicker_search_bar_header">
                    <form>
                        <div class="quicker_search_bar">
                            <input type="text" class="flexdatalist form-control" data-min-length='0' placeholder="What are you looking for?" required="" list="languages">
                                <datalist id="languages" onmouseleave="this.form.submit()">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            <input type="submit" value="Get Quotes" id="getQuoteBtn" data-backdrop="static" data-keyboard="false">
                        </div>
                    </form>
               </div>
           </div>
           <!-- /row -->
       </div>
       <!-- /container -->
</div>



<main>
  <div class="container mt-3 mb-3">
    <?php if(count($jobs)==0): ?>
      <div class="box_booking" style="min-height: 400px">
          <div class="row align-items-center" style="height: 400px;">
            <div class="col-12 mx-auto text-center">
                  <div class="row">
                    <div class="col-md-12">
                      <span style="font-size: 90px;" class="pe-7s-news-paper"> </span> 
                      <p style="font-size: 24px;">No Quote request posted yet!</p>
                    </div>
                  </div>
            </div>
          </div>
      </div>   
      <?php else: ?>
    <div class="box_booking" style="min-height: 400px">
      
      <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="strip_booking">
        <div class="row">
            <div class="col-lg-2 col-md-2 col-6">
              <div class="date">
                <span class="month"><?php echo e(date('M', strtotime($job->created_at))); ?></span>
                <span class="day">
                  <strong><?php echo e(date('d', strtotime($job->created_at))); ?></strong>
                  <?php echo e(date('D', strtotime($job->created_at))); ?>

                </span>
              </div>
            </div>
            <div class="col-lg-6 col-md-5 col-6 strip_detail">
              <?php echo e($job->title); ?>

              <br>
              <?php $__currentLoopData = $job->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <span class="badge badge-primary"><?php echo e($category->name); ?></span>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
              <ul class="info_booking">
                <li><strong>Job id:</strong> <?php echo e($job->id); ?></li>
                <li><strong>Created on:</strong> <?php echo e(date('d M Y', strtotime($job->created_at))); ?></li>
              </ul>
            </div>
            <div class="col-lg-2 col-md-2 col-6">
              <div class="booking_buttons">
                
                <a href="#" class="btn_2">View Quotes</a>
              </div>
            </div>
        </div>

      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
  </div>
</main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-class'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>