
<!-- The Modal -->
<div class="modal quote-modal" id="myModal" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog modal-lg modal-custom-lg">
    <div class="modal-content quote-modal-block">
	    <div class="modal-header">
	     	<button type="button" class="close" data-dismiss="modal">&times;</button>
	    </div>

      <!-- Modal body -->
      <div class="modal-body cutsom-scroll pt-0">
	       	
	       	<!-- Smart Wizard HTML -->
              <div id="smartwizard">
                  <ul>
                      <li><a href="#step-1">Step Title<br /><small>Step description</small></a></li>
                      <li><a href="#step-2">Step Title<br /><small>Step description</small></a></li>
                      <li><a href="#step-3">Step Title<br /><small>Step description</small></a></li>
                      <li><a href="#step-4">Step Title<br /><small>Step description</small></a></li>
                  </ul>

                  <div>
                      <div id="step-1" class="">
                          Step Content
                      </div>
                      <div id="step-2" class="">
                          Step Content
                      </div>
                      <div id="step-3" class="">
                          Step Content
                      </div>
                      <div id="step-4" class="">
                          Step Content
                      </div>
                  </div>
              </div>

      </div>
    </div>
  </div>
</div>


<script type="text/javascript">
$("#myModal").modal("show");
</script>


<script type="text/javascript">
  $(document).ready(function() {
      
      // Smart Wizard
      $('#smartwizard').smartWizard({
            selected: 0,  // Initial selected step, 0 = first step 
            keyNavigation:true, // Enable/Disable keyboard navigation(left and right keys are used if enabled)
            autoAdjustHeight:true, // Automatically adjust content height
            cycleSteps: false, // Allows to cycle the navigation of steps
            backButtonSupport: true, // Enable the back button support
            useURLhash: true, // Enable selection of the step based on url hash
            lang: {  // Language variables
                next: 'Next', 
                previous: 'Previous'
            },
            toolbarSettings: {
                toolbarPosition: 'bottom', // none, top, bottom, both
                toolbarButtonPosition: 'right', // left, right
                showNextButton: true, // show/hide a Next button
                showPreviousButton: true, // show/hide a Previous button
                toolbarExtraButtons: [
			$('<button></button>').text('Finish')
					      .addClass('btn btn-info')
					      .on('click', function(){ 
						alert('Finsih button click');                            
					      }),
			$('<button></button>').text('Cancel')
					      .addClass('btn btn-danger')
					      .on('click', function(){ 
						alert('Cancel button click');                            
					      })
                      ]
            }, 
            anchorSettings: {
                anchorClickable: true, // Enable/Disable anchor navigation
                enableAllAnchors: false, // Activates all anchors clickable all times
                markDoneStep: true, // add done css
                enableAnchorOnDoneStep: true // Enable/Disable the done steps navigation
            },            
            contentURL: null, // content url, Enables Ajax content loading. can set as data data-content-url on anchor
            disabledSteps: [],    // Array Steps disabled
            errorSteps: [],    // Highlight step with errors
            theme: 'dots',
            transitionEffect: 'fade', // Effect on navigation, none/slide/fade
            transitionSpeed: '400'
      });
      
  }); 
</script>
