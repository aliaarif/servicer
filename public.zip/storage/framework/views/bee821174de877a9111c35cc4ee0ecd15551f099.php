<?php $__env->startSection('title'); ?>
Register | Quicker
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-class'); ?>
id="register_bg"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-class'); ?>
d-none
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<nav id="menu" class="fake_menu"></nav>

<div id="login">
        <aside>
            <figure>
                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('assets/img/logo.png')); ?>" height="35" alt="" class="logo_sticky"></a>
            </figure>
            <h6 class="text-center">Quicker Registration</h6>

            <form method="POST" action="<?php echo e(url('servicer/register')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="user_type_id" value="2">
                <div class="form-group">
                    <label>First Name</label>
                    <input id="name" type="text" class="form-control<?php echo e($errors->has('first_name') ? ' is-invalid' : ''); ?>" name="first_name" value="<?php echo e(old('first_name')); ?>" required autofocus>
                    <i class="ti-user"></i>
                    <?php if($errors->has('first_name')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('first_name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label>Last Name</label>
                    <input id="name" type="text" class="form-control<?php echo e($errors->has('last_name') ? ' is-invalid' : ''); ?>" name="last_name" value="<?php echo e(old('last_name')); ?>" required autofocus>
                    <i class="ti-user"></i>
                    <?php if($errors->has('last_name')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('last_name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label>Your Email</label>
                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
                    <i class="icon_mail_alt"></i>
                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label>Your password</label>
                    <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                    <i class="icon_lock_alt"></i>
                    <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label>Confirm password</label>
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                    <i class="icon_lock_alt"></i>
                </div>
                <div id="pass-info" class="clearfix"></div>
                <button type="submit" class="btn_1 rounded full-width">
                    <?php echo e(__('Register')); ?>

                </button>
                
                <div class="text-center add_top_10"><strong><a href="<?php echo e(url('/')); ?>"><i class="icon-home"></i> Home</a></strong></div>
            </form>
            <div class="copy">© 2018 Quicker</div>
        </aside>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-class'); ?>
d-none
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>