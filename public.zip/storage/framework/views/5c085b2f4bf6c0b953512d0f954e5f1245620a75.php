<?php $__env->startSection('title'); ?>
Dashboard | Quicker
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="sub_header_in sticky_header" style="margin-top: 0px;">
  <div class="container">
    <h1>Job History</h1>
    <div class="row">
      <div class="col-md-12 navigational">
          <div class="breadcrumbs">
            <ul class="list-inline">
               <li class="list-inline-item"><a href="<?php echo e(url('home')); ?>"><strong>Dashboard</strong></a></li>/
               <li class="list-inline-item"><strong>Jobs</strong></li>
               
           </ul>
          </div>
          <div class="back-btn">
            <a href="<?php echo e(url('home')); ?>"><button class="btn btn-primary">Back</button></a>
          </div>
      </div>
    </div>
  </div>
  <!-- /container -->
</div>



<main>
  <div class="container margin_80_35">
    <?php if(count($jobs)==0): ?>
        <div class="row align-items-center" style="height: 400px;">
          <div class="col-12 mx-auto text-center">
                <div class="row">
                  <div class="col-md-12">
                    <span style="font-size: 90px;" class="ti-alert"> </span> 
                  </div>
                </div>
                <div class="col-md-12 text-center">
                  <p style="font-weight: strong;font-size: 30px;">Data Not Found</p>
                </div>
          </div>
      </div>
       

      <?php else: ?>
    <div class="box_booking" style="min-height: 400px">
      

      <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="strip_booking">
        <div class="row">
            <div class="col-lg-2 col-md-2">
              <div class="date">
                <span class="month"><?php echo e(date('M', strtotime($job->date))); ?></span>
                <span class="day"><strong><?php echo e(date('d', strtotime($job->date))); ?></strong><?php echo e(date('D', strtotime($job->date))); ?></span>
              </div>
            </div>
            <div class="col-lg-6 col-md-5">
<?php 
if (strlen($job->description) > 350) {

    // truncate string
    $stringCut = substr($job->description, 0, 350);
    $endPoint = strrpos($stringCut, ' ');

    //if the string doesn't contain any space then it will cut without word basis.
    $string = $endPoint? substr($stringCut, 0, $endPoint) : substr($stringCut, 0);
    $string .= '...';
}else{
    $string = $job->description;
}
?>              
              <h3 class="hotel_booking"><?php echo e($job->title); ?><span><?php echo e($string); ?></span></h3>
            </div>
            <div class="col-lg-2 col-md-3">
              <ul class="info_booking">
                <li><strong>Job id</strong> <?php echo e($job->id); ?></li>
                <li><strong>Created on</strong> <?php echo e(date('d M Y', strtotime($job->created_at))); ?></li>
              </ul>
            </div>
            <div class="col-lg-2 col-md-2">
              <div class="booking_buttons">
                <a href="<?php echo e(url('/home/job/'.$job->id.'/details')); ?>" class="btn_2">Details</a>
                <a href="<?php echo e(url('/home/job/'.$job->id.'/quotes')); ?>" class="btn_3">Quotes</a>
              </div>
            </div>
          </div>

      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
  </div>
</main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-class'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>