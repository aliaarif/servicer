<?php $__env->startSection('title'); ?>
Job Categories | Quicker
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="sub_header_in sticky_header" style="margin-top: 0px;">
	<div class="container">
		<h1>Browse Jobs by Categories</h1>
	</div>
	<!-- /container -->
</div>

<main>
	<?php if(count($categories)!=0): ?>
		<div class="container margin_60_35">
			<div class="row">
				<div class="col-md-12">
					<div class="input-group mb-3 input-group-lg">
						<div class="input-group-prepend">
							<span class="input-group-text" id="basic-addon1"><i class="icon-search-5"></i></span>
						</div>
						<input type="text" class="form-control" placeholder="Search for a Category" aria-label="Username" aria-describedby="basic-addon1" id="search-text" name="search-text">
					</div>
					
					<!-- <div id="search-result">
						<div class="box_booking">
							<div class="list_articles add_bottom_30 clearfix">
								<ul id="search-result-list">

								</ul>
							</div>
						</div>
					</div> -->



					<div id="search-result">
						<div class="box_booking">
							<div class="icon-section clearfix" id="search-result-list">

							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="main_title_2 mt-5">
				<span><em></em></span>
				<h2>Select a Category</h2>
				
			</div>
			<div class="row">
				<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-4 col-md-6">
					<a class="box_topic" href="#0" data-target="<?php echo e('#'.str_replace(' ', '_', strtolower($category->name))); ?>">
						<span><i class="pe-7s-wallet"></i></span>
						<h3><?php echo e($category->name); ?></h3>
						
					</a>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			</div>
		</div>
		<div class="bg_color_1">	
			<div class="container margin_80_55">
			<!--/row-->
				<div class="main_title_2">
					<span><em></em></span>
					<h2>Browse all Categories</h2>
					
				</div>
				<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="icon-section clearfix" id="<?php echo e(str_replace(' ', '_', strtolower($category->name))); ?>">
					
					<h3 class="category-header"><?php echo e($category->name); ?> </h3>
					<div>
						<?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						
							<div class="icon-container" data-title="<?php echo e(strtolower($subcategory->name)); ?>">
								<a href="<?php echo e(url('categories/'.$subcategory->id.'/jobs')); ?>">
									<i class="icon-right-bold"></i><span class="icon-name"> <?php echo e($subcategory->name); ?></span>
								</a>
							</div>
						
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
						

					
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>	
			<!-- /list_articles -->
		</div>
	<?php else: ?> 
		<div class="row align-items-center" style="height: 400px;">
	        <div class="col-12 mx-auto text-center">
	            	<div class="row">
	            		<div class="col-md-12">
	            			<span style="font-size: 90px;" class="ti-alert"> </span> 
	            		</div>
	            	</div>
	            	<div class="col-md-12 text-center">
	            		<p style="font-weight: strong;font-size: 30px;">Data Not Found</p>
	            	</div>
	        </div>
	    </div>

	<?php endif; ?>	
		<!-- /container -->
</main>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$("#search-result").hide();
	});

	$(".box_topic").click(function() {
		var selected_div = ($(this).attr('data-target'));
	    $('html, body').animate({
	        scrollTop: $(selected_div).offset().top-30
	    }, 300);
	});

	$("#search-text").keyup(function(){
		$("#search-result-list").html("");
		if($(this).val().length != 0){
			var searchText = $(this).val();
			var resultingElement = $("[data-title*='"+searchText+"']");
			if(resultingElement.length > 0){
				$("#search-result-list").append("<h5> Matching Results: </h5>");
				resultingElement.each(function(index){
					$("#search-result-list").append("<div class='icon-container'>"+$(resultingElement[index]).html()+"</div>");
				});
			}else{
				$("#search-result-list").append("<h5 class='text-center'> No Result Found! </h5>");
			}
			$("#search-result").slideDown(100);
		}else{
			$("#search-result").slideUp(100);
		}
	});	

	
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>