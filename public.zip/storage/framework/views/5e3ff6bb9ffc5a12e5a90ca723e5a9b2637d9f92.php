<?php $__env->startSection('title'); ?>
User Register | Quicker
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-class'); ?>
id="register_bg"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-class'); ?>
d-none
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<nav id="menu" class="fake_menu"></nav>

<div id="login">
        <aside>
            <figure>
                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('assets/img/logo.png')); ?>" height="35" alt="" class="logo_sticky"></a>
            </figure>
            <h6 class="text-center">User Registration</h6>
            <div class="row mt-3">
                <div class="col-6 pl-1 pr-1">
                    <a href="#0" class="social_bt facebook"> Facebook</a>
                </div>
                <div class="col-6 pl-1 pr-1">
                    <a href="#0" class="social_bt google"> Google</a>
                </div>
            </div>
            <div class="divider"><span>Or</span></div>

            <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="user_type_id" value="1">
                <div class="form-group">
                    <label>Your Name</label>
                    <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
                    <i class="ti-user"></i>
                    <?php if($errors->has('name')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label>Your Email</label>
                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
                    <i class="icon_mail_alt"></i>
                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label>Your password</label>
                    <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                    <i class="icon_lock_alt"></i>
                    <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label>Confirm password</label>
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                    <i class="icon_lock_alt"></i>
                </div>
                <div id="pass-info" class="clearfix"></div>
                <button type="submit" class="btn_1 rounded full-width">
                    <?php echo e(__('Register')); ?>

                </button>
                
                <div class="text-center add_top_10"><strong><a href="<?php echo e(url('/')); ?>"><i class="icon-home"></i> Home</a></strong></div>
            </form>
            <div class="copy">© 2018 Quicker</div>
        </aside>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-class'); ?>
d-none
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>