<?php $__env->startSection('title'); ?>
Quicker
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-class'); ?>
class="cutsom-scroll"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-class'); ?>
d-none
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form id="formLocation" method="POST" action="<?php echo e(url('quote/'.$category_id.'/step-4/'.$job_id)); ?>"> 
<?php echo csrf_field(); ?>        

<main>
    <div class="container margin_60">
         <div class="row justify-content-center">
            <div class="col-md-5">
                <div id="confirm">
                    <div class="icon icon--order-success svg add_bottom_15">
                        <svg xmlns="http://www.w3.org/2000/svg" width="72" height="72">
                            <g fill="none" stroke="#8EC343" stroke-width="2">
                                <circle cx="36" cy="36" r="35" style="stroke-dasharray:240px, 240px; stroke-dashoffset: 480px;"></circle>
                                <path d="M17.417,37.778l9.93,9.909l25.444-25.393" style="stroke-dasharray:50px, 50px; stroke-dashoffset: 0px;"></path>
                            </g>
                        </svg>
                    </div>
                <h2>Quote Request Sent!</h2>
                <p>
                    We have sent your quote request to nearby Quickers.<br/>
                    You will start receiving quote for your request soon.
                </p>
                <button class="btn btn-warning" type="button" onclick="closeModal();">close</button>
                </div>
            </div>
        </div>
        <!-- /row -->
    </div>
<!-- /container -->
</main>
<div class="snackbar <?php if(session('snackbar-message')): ?> show <?php endif; ?>"><?php if(session('snackbar-message')): ?> <?php echo e(session('snackbar-message')); ?> <?php endif; ?></div>


</form>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-class'); ?>
d-none
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modals'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
function closeModal(){
    $('#getQuoteModal button.close', parent.document).trigger('click');
}
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>