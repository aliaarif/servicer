<?php $__env->startSection('title'); ?>
Profile | Quicker
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="results" style="padding: 10px 0;">
       <div class="container">
           <div class="row">
               <div class="col-lg-3 col-md-4 col-10 d-none d-lg-block">
                   <h4 style="font-size: 18px;">Profile</h4>
               </div>
               <div class="col-lg-9 quicker_search_bar_header">
                    <form>
                        <div class="quicker_search_bar">
                            <input type="text" class="flexdatalist form-control" data-min-length='0' placeholder="What are you looking for?" required="" list="languages">
                                <datalist id="languages" onmouseleave="this.form.submit()">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            <input type="submit" value="Get Quotes" id="getQuoteBtn" data-backdrop="static" data-keyboard="false">
                        </div>
                    </form>
               </div>
           </div>
           <!-- /row -->
       </div>
       <!-- /container -->
</div>
<!-- /sub_header -->
<div class="container">
	<div class="row mt-3 mb-3">
		<aside class="col-lg-3" id="faq_cat">
				<div class="box_style_cat" id="faq_box">
					<ul id="cat_nav">
						<li><a href="<?php echo e(url('/home/update-profile')); ?>"> Profile</a></li>
						<li><a href="<?php echo e(url('/home/update-password')); ?>"> Update Password</a></li>
					</ul>
				</div>
				<!--/sticky -->
		</aside>
		<!--/aside -->
		
		<div class="col-lg-9">
			<section style="background: white; padding: 20px">
				<div class="row">  
					<div class="col-md-12 d-md-none d-lg-none d-xl-none">
						<select class="form-control form-group" name="filter" id="filter" required="" onChange="window.document.location.href=this.options[this.selectedIndex].value;" value="GO" placeholder="">
	                    <option value="">Select Account</option>
	                  
	                    <option value="<?php echo e(url('home/update-profile')); ?>">Update Profile</option>
	                    <option value="<?php echo e(url('home/update-password')); ?>">Update Password</option>
	                  
	                </select>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<h4 style="text-align: center;">Update Account</h4>
						<hr>
					</div>
				</div>	
				<form name="frmAvatar" id="frmAvatar" class="hidden" style="display: none" enctype="multipart/form-data" action="<?php echo e(url('home/update-profile-photo')); ?>" method="POST">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input id="photoId" style="display: none" type="file" name="avatar">
                <input type="submit" style="display: none" value="submit">
              </form>

				<form action="<?php echo e(url('home/save-update-profile')); ?>" method="post"  enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
				<div class="row">
					<div class="col-md-4 text-center">
						<?php if($user->avatar == ''): ?>
						
						<img class="img-responsive rounded-circle" style="height: 200px; margin-bottom:10px;" src="<?php echo e(asset('/uploads/avatar.jpg')); ?>" alt="">

						
						<?php else: ?>
						
						<img class="img-responsive rounded-circle" style="height: 200px; margin-bottom:10px;" src="<?php echo e(asset('/uploads/profiles/'.$user->avatar)); ?>" alt=""><br>
						
						<?php endif; ?>
						<button type="button" class="btn btn-primary btn-sm" id="changeProfileImage" onclick="selectImage()">Change</button>
					</div>
					<div class="col-md-8">
							<div class="row">
							    <div class="form-group col-md-6">
							      <label for="inputFirstname">First Name</label>
							      <input type="text" name="first_name" class="form-control" id="name" placeholder="First First Name" value="<?php echo e($user->first_name); ?>">
							    </div>
							    <div class="form-group col-md-6">
							      <label for="inputFirstname">Last Name</label>
							      <input type="text" name="last_name" class="form-control" id="name" placeholder="First Last Name" value="<?php echo e($user->last_name); ?>">
							    </div>
						 	</div>
						  <div class="row">
						    <div class="form-group col-md-6">
						      <label for="inputEmail4">Email</label>
						      <input type="email" name="email" class="form-control" id="inputEmail4" placeholder="Email" value="<?php echo e($user->email); ?>" readonly="readonly">
						    </div>
						  
						    <div class="form-group col-md-6">
						      <label for="inputMobile">Mobile</label>
						      <input type="text" name="mobile" class="form-control" id="inputMobile" placeholder="Mobile" value="<?php echo e($user->mobile); ?>">
						    </div>
						  </div>
						  <div class="form-group">
						    <label for="inputAddress">Address</label>
						    <input type="text" name="address" class="form-control" id="inputAddress" placeholder="" value="<?php echo e($user->address); ?>">
						  </div>
						  <div class="row">
						    
						    <div class="form-group col-md-4">
						      <label for="inputApt">Apt / Unit</label>
						      <input type="text" name="apt_no" class="form-control" id="inputApt" value="<?php echo e($user->apt_no); ?>">
						    </div>
								
								<div class="form-group col-md-4">
						      <label for="inputCity">Town / City</label>
						      <select name="city" class="form-control select2" id="inputCity">
						      	<option  value="">--Select City --</option>
						      	<?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						      	<option <?php echo e($cities->id == $user->city_id ? 'selected' : ''); ?> value="<?php echo e($cities->id); ?>"><?php echo e($cities->city); ?></option>
						      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						      
						      </select>
						    </div>

						    <div class="form-group col-md-4">
						      <label for="inputPincode">Pincode</label>
						      <input type="text" name="pincode" class="form-control" id="inputPincode" value="<?php echo e($user->pincode); ?>">
						    </div>
						  </div>
					  	<button type="submit" class="btn btn-outline-primary">Update Profile</button>
					</div>
					
				</div>
				</form>
			</section>
			<!-- /accordion payment -->
		</div>
		<!-- /col -->
	</div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
	function selectImage() {
		;(function($){
			$('#photoId').trigger('click');
		})(jQuery);
	}
</script>

<script>
;(function($){
document.getElementById("photoId").onchange = function() {
	
    $("#frmAvatar").submit();
    $("#preloader").fadeIn();
    
}
})(jQuery);

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>