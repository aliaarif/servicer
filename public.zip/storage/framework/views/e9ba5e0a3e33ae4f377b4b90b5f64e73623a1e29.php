<?php $__env->startSection('title'); ?>
Quicker Reset Password | Quicker
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-class'); ?>
id="login_bg"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-class'); ?>
d-none
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<nav id="menu" class="fake_menu"></nav>
    
    <div id="login">
        <aside>
            <figure>
                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('assets/img/logo.png')); ?>" height="35" alt="" class="logo_sticky"></a>
            </figure>

                <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(url('servicer/password/email')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="user_type_id" value="2">
                <div class="form-group">
                    <label>Email Address</label>
                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
                    <i class="icon_mail_alt"></i>
                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <input type="submit" class="btn_1 rounded full-width" name="login" value="Send Password Reset Link">
                <div class="text-center add_top_10">Already have an acccount? <strong><a href="<?php echo e(url('servicer/login')); ?>">Login</a></strong></div>
                <div class="text-center add_top_10"><strong><a href="<?php echo e(url('/')); ?>"><i class="icon-home"></i> Home</a></strong></div>
            </form>
            <div class="copy">© 2018 Quicker</div>
        </aside>
    </div>
    <!-- /login -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-class'); ?>
d-none
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>