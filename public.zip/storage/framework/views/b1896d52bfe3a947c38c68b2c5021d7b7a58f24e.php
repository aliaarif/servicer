<?php $__env->startSection('title'); ?>
Job Category | Quicker
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="sub_header_in sticky_header" style="margin-top: 0px;">
	<div class="container">
		<h1><?php echo e($category->name); ?> Jobs</h1>
	</div>
	<!-- /container -->
</div>

<main>
		
	   		
		
		
		<div class="collapse" id="collapseMap">
			<div id="map" class="map"></div>
		</div>
		<!-- /Map -->
		
		<div class="container margin_60_35">
			<?php if(count($jobs) != 0): ?>
			<div class="row">
				<aside class="col-lg-3" id="sidebar">
					<div id="filters_col">
						<a data-toggle="collapse" href="#collapseFilters" aria-expanded="false" aria-controls="collapseFilters" id="filters_col_bt">Filters </a>
						<div class="collapse show" id="collapseFilters">
							<div class="filter_type">
								<h6>Category</h6>
								<ul>
									<li>
										<label class="container_check">Restaurants <small>245</small>
										  <input type="checkbox">
										  <span class="checkmark"></span>
										</label>
									</li>
									<li>
										<label class="container_check">Shops <small>43</small>
										  <input type="checkbox">
										  <span class="checkmark"></span>
										</label>
									</li>
									<li>
										<label class="container_check">Bars <small>13</small>
										  <input type="checkbox">
										  <span class="checkmark"></span>
										</label>
									</li>
									<li>
										<label class="container_check">Events <small>65</small>
										  <input type="checkbox">
										  <span class="checkmark"></span>
										</label>
									</li>
								</ul>
							</div>
							<div class="filter_type">
                                <h6>Distance</h6>
                                <div class="distance"> Radius around selected destination <span></span> km</div>
								<input type="range" min="10" max="100" step="10" value="30" data-orientation="horizontal">
                            </div>
							<div class="filter_type">
								<h6>Rating</h6>
								<ul>
									<li>
										<label class="container_check">Superb 9+ <small>102</small>
										  <input type="checkbox">
										  <span class="checkmark"></span>
										</label>
									</li>
									<li>
										<label class="container_check">Very Good 8+ <small>122</small>
										  <input type="checkbox">
										  <span class="checkmark"></span>
										</label>
									</li>
									<li>
										<label class="container_check">Good 7+ <small>54</small>
										  <input type="checkbox">
										  <span class="checkmark"></span>
										</label>
									</li>
									<li>
										<label class="container_check">Pleasant 6+ <small>23</small>
										  <input type="checkbox">
										  <span class="checkmark"></span>
										</label>
									</li>
								</ul>
							</div>
						</div>
						<!--/collapse -->
					</div>
					<!--/filters col-->
				</aside>
				<!-- /aside -->

				<div class="col-lg-9" id="job-listing">
					<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="strip list_view">
						<div class="row no-gutters">
							
							<div class="col-lg-12">
								<div class="wrapper">
									
									<h3><a href="detail-restaurant.html"><?php echo e($job->title); ?></a></h3>
					<?php 
					if (strlen($job->description) > 300) {

					    // truncate string
					    $stringCut = substr($job->description, 0, 300);
					    $endPoint = strrpos($stringCut, ' ');

					    //if the string doesn't contain any space then it will cut without word basis.
					    $string = $endPoint? substr($stringCut, 0, $endPoint) : substr($stringCut, 0);
					    $string .= '...';
					}else{
						$string = $job->description;
					}
					?>
									<p class="text-justify"><?php echo e($string); ?></p>
									<small>Categories : 
										<?php $__currentLoopData = $job->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
											<a href="<?php echo e(url('categories/'.$subcategory->id.'/jobs')); ?>"><span class="badge badge-pill badge-primary"><?php echo e($subcategory->name); ?></span></a>
											<?php if($key+1 < count($job->categories)): ?>
											<?php echo e(","); ?>

											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</small>
								</div>
								<ul class="text-right">
									<button class="btn btn-info btn-sm">Job Details</button>
									<button class="btn btn-success btn-sm">Send Quote</button>
								</ul>
							</div>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<div class="row">
						<div class="col-md-12 text-center">
							<?php echo e($jobs->links()); ?>

						</div>
					</div>
					
					<!-- <p class="text-center"><a href="#0" class="btn_1 rounded add_top_30">Load more</a></p> -->
				</div>
				<!-- /col -->
			</div>
			<?php else: ?> 

			<div class="row align-items-center" style="height: 400px;">
		        <div class="col-12 mx-auto text-center">
		            	<div class="row">
		            		<div class="col-md-12">
		            			<span style="font-size: 90px;" class="ti-alert"> </span> 
		            		</div>
		            	</div>
		            	<div class="col-md-12 text-center">
		            		<p style="font-weight: strong;font-size: 30px;">Data Not Found</p>
		            	</div>
		        </div>
		    </div>

			<?php endif; ?>	
		</div>
		<!-- /container -->
		
	</main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>