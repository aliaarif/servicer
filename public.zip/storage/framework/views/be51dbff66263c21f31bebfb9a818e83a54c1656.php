<?php $__env->startSection('title'); ?>
Profile | Quicker
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="results" style="padding: 10px 0;">
       <div class="container">
           <div class="row">
               <div class="col-lg-3 col-md-4 col-10 d-none d-lg-block">
                   <h4 style="font-size: 18px;">Change Password</h4>
               </div>
               <div class="col-lg-9 quicker_search_bar_header">
                    <form>
                        <div class="quicker_search_bar">
                            <input type="text" class="flexdatalist form-control" data-min-length='0' placeholder="What are you looking for?" required="" list="languages">
                                <datalist id="languages" onmouseleave="this.form.submit()">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            <input type="submit" value="Get Quotes" id="getQuoteBtn" data-backdrop="static" data-keyboard="false">
                        </div>
                    </form>
               </div>
           </div>
           <!-- /row -->
       </div>
       <!-- /container -->
    </div>
<!-- /sub_header -->
<div class="container">
	<div class="row mt-3 mb-3">
		<aside class="col-lg-3" id="faq_cat">
				<div class="box_style_cat" id="faq_box">
					<ul id="cat_nav">
					<!-- 	<li><a href="<?php echo e(url('/home/view-profile')); ?>"> Profile</a></li> -->
						<li><a href="<?php echo e(url('/home/update-profile')); ?>"> Profile</a></li>
						<li><a href="<?php echo e(url('/home/update-password')); ?>"> Update Password</a></li>
						
					</ul>
				</div>
				<!--/sticky -->
		</aside>
		<!--/aside -->
		
		<div class="col-lg-9">
			<section style="background: white; padding: 20px">
				<div class="col-md-12 d-md-none d-lg-none d-xl-none">
					<select class="form-control form-group dropdown" name="filter" id="filter" required="" onChange="window.document.location.href=this.options[this.selectedIndex].value;" value="GO" placeholder="">
						 <option value="">Select Account</option>
                     <option value="<?php echo e(url('home/update-profile')); ?>">Update Profile</option>
	                    <option value="<?php echo e(url('home/update-password')); ?>">Update Password</option>
	                  
                </select>
				</div>
				<h4 style="text-align: center;">Change Password</h4>
				<hr>
				<form action="<?php echo e(url('home/save-update-password')); ?>" method="post">
					<?php echo csrf_field(); ?>
				<div class="row">
					
					<div class="col-md-12">
							<div class="form-row">
						    <div class="form-group col-md-12">
						      <label for="inputFirstname">Enter current password:</label>
						      <input type="password" name="original_password" class="form-control" placeholder="" >
						    </div>
						  </div>
						  <div class="form-row">
						    <div class="form-group col-md-12">
						      <label for="inputEmail4">Enter new password:</label>
						      <input type="password" name="password" class="form-control" placeholder="">
						    </div>
						  </div>
						  <div class="form-row">
						    <div class="form-group col-md-12">
						      <label for="inputEmail4">Confirm new password:</label>
						      <input type="password" name="password_confirmation" class="form-control" placeholder="">
						    </div>
						  </div>
					  	
					  	<button type="submit" class="btn btn-outline-primary">Change Password</button>
					</div>
					
				</div>
				</form>
			</section>
			<!-- /accordion payment -->
		</div>
		<!-- /col -->
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>