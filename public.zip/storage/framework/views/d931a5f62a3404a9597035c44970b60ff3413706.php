<?php $__env->startSection('title'); ?>
User Login | Quicker
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-class'); ?>
id="login_bg"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-class'); ?>
d-none
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<nav id="menu" class="fake_menu"></nav>
    
    <div id="login">
        <aside>
            <figure>
                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('assets/img/logo.png')); ?>" height="35" alt="" class="logo_sticky"></a>
            </figure>
                <h6 class="text-center">User Login</h6>
                <div class="">
                    <a href="#0" class="social_bt facebook">Login with Facebook</a>
                    <a href="#0" class="social_bt google">Login with Google</a>
                </div>
                <div class="divider"><span>Or</span></div>

              <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="user_type_id" value="1">
                <div class="form-group">
                    <label>Email</label>
                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                    <i class="icon_mail_alt"></i>

                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                    <i class="icon_lock_alt"></i>

                    <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="clearfix add_bottom_30">
                    <div class="checkboxes float-left">
                        <label class="container_check">Remember me
                          <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                          <span class="checkmark"></span>
                        </label>
                    </div>
                    <div class="float-right mt-1"><a id="forgot" href="<?php echo e(route('password.request')); ?>">Forgot Password?</a></div>
                </div>
                <input type="submit" class="btn_1 rounded full-width" name="login" value="Login Now">
                <div class="text-center add_top_10">New to Quicker? <strong><a href="<?php echo e(url('register')); ?>">Register</a></strong></div>
                <div class="text-center add_top_10"><strong><a href="<?php echo e(url('/')); ?>"><i class="icon-home"></i> Home</a></strong></div>
            </form>
            <div class="copy">© 2018 Quicker</div>
        </aside>
    </div>
    <!-- /login -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-class'); ?>
d-none
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>