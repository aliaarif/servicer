<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Quicker">
    <meta name="author" content="Quicker">
     <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="_token" content="<?php echo csrf_token(); ?>" />
    <meta name="_path" content="<?php echo e(url('/')); ?>" />
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Favicons-->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/favicon.ico')); ?>" type="image/x-icon">
    <link rel="apple-touch-icon" type="image/x-icon" href="<?php echo e(asset('assets/img/apple-touch-icon-57x57-precomposed.png')); ?>">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="<?php echo e(asset('assets/img/apple-touch-icon-72x72-precomposed.png')); ?>">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="<?php echo e(asset('assets/img/apple-touch-icon-114x114-precomposed.png')); ?>">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="<?php echo e(asset('assets/img/apple-touch-icon-144x144-precomposed.png')); ?>">

    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('assets/css/vendors.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('assets/css/dropzone.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('assets/css/jquery.flexdatalist.min.css')); ?>" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/toastr.min.css')); ?>">
	<link href="<?php echo e(asset('assets/css/select2.min.css')); ?>" rel="stylesheet" />
    <!-- YOUR CUSTOM CSS -->
    <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet">

</head>

<body <?php echo $__env->yieldContent('body-class'); ?>>	
	<div id="page">

	<?php if(Auth::guard('servicer')->user()): ?>
		<?php echo $__env->make('includes.header-servicer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php elseif(Auth::guard('web')->user()): ?>
		<?php echo $__env->make('includes.header-user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php else: ?>
		<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php endif; ?>
	<!-- /header -->

	<?php echo $__env->yieldContent('content'); ?>

	<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!--/footer-->

	</div>
	<!-- page -->

	<div id="toTop"></div><!-- Back to top button -->
	
	<!-- COMMON SCRIPTS -->
    <script src="<?php echo e(asset('assets/js/common_scripts.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/functions.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/jquery.flexdatalist.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/assets/validate.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/parsley.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('assets/js/toastr.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/dropzone.js')); ?>"></script>
	
	    <script type="text/javascript">
		    toastr.options = {
		      "closeButton": false,
		      "debug": false,
		      "newestOnTop": false,
		      "progressBar": false,
		      "positionClass": "toast-top-right",
		      "preventDuplicates": false,
		      "onclick": null,
		      "showDuration": "300",
		      "hideDuration": "1000",
		      "timeOut": "5000",
		      "extendedTimeOut": "1000",
		      "showEasing": "swing",
		      "hideEasing": "linear",
		      "showMethod": "fadeIn",
		      "hideMethod": "fadeOut"
		    }
		</script>
		
		<script type="text/javascript">
		<?php if(count($errors) > 0): ?>
		    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
		        toastr.error("<?php echo e($error); ?>");
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>

		<?php if(session('success-message')): ?>
		    toastr.success("<?php echo e(session('success-message')); ?>");
		<?php endif; ?>

		<?php if(session('error-message')): ?>
		    toastr.error("<?php echo e(session('error-message')); ?>");
		<?php endif; ?>

		</script>


	<!-- bootstrap modals -->
	<?php echo $__env->yieldContent('modals'); ?>
	

	<!-- Sign In Popup -->
	<div id="sign-in-dialog" class="zoom-anim-dialog mfp-hide">
		<div class="small-dialog-header mb-0">
			<h3>Login</h3>
		</div>

			<div class="row text-center mt-2 mb-3">
				<div class="col-6 pl-1 pr-1">
					<a href="#" onclick="loginBlock(1);"><div class="btn-link btn-block" id="userLoginBlockBtn">User Login</div></a>
				</div>
				<div class="col-6 pl-1 pr-1">
					<a href="#" onclick="loginBlock(2);"><div class="btn-link btn-block" id="quickerLoginBlockBtn">Quicker Login</div></a>
				</div>
			</div>

			<div class="sign-in-wrapper" id="userLoginBlock">
				<div id="userLoginBox">
					<form method="POST" action="<?php echo e(route('login')); ?>">
						<?php echo csrf_field(); ?>
						<input type="hidden" name="user_type_id" value="1">
						
						

						<div class="form-group">
							<label>Email</label>
							<input type="email" class="form-control <?php if(old('user_type_id') == 1): ?> <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>  <?php endif; ?>" name="email" value="<?php if(old('user_type_id') == 1): ?> <?php echo e(old('email')); ?> <?php endif; ?>" required autofocus>
							<i class="icon_mail_alt"></i>
							<?php if(old('user_type_id') == 1): ?>
							<?php if($errors->has('email')): ?>
		                        <span class="invalid-feedback" role="alert">
		                            <strong><?php echo e($errors->first('email')); ?></strong>
		                        </span>
		                    <?php endif; ?>
		                    <?php endif; ?>
						</div>
						<div class="form-group">
							<label>Password</label>
							<input type="password" class="form-control <?php if(old('user_type_id') == 1): ?> <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?> <?php endif; ?>" name="password" required>
							<i class="icon_lock_alt"></i>
							<?php if(old('user_type_id') == 1): ?>
							<?php if($errors->has('password')): ?>
		                        <span class="invalid-feedback" role="alert">
		                            <strong><?php echo e($errors->first('password')); ?></strong>
		                        </span>
		                    <?php endif; ?>
		                    <?php endif; ?>
						</div>
						<div class="clearfix add_bottom_15">
							<div class="checkboxes float-left">
								<label class="container_check">Remember me
								  <input class="form-check-input" type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
								  <span class="checkmark"></span>
								</label>
							</div>
							<div class="float-right mt-1"><label><a style="color: #999;" href="<?php echo e(route('password.request')); ?>">Forgot Password?</a></label></div>
						</div>
						<div class="text-center"><input type="submit" value="Log In" class="btn_1 full-width"></div>
						<div class="text-center mt-2">
							Don’t have an account? <a href="#" onclick="switchLogin('register');">Register</a>
						</div>
					</form>
				</div>
				<div id="userRegisterBox" style="display: none;">
					<form method="POST" action="<?php echo e(route('register')); ?>">
						<?php echo csrf_field(); ?>
						<input type="hidden" name="user_type_id" value="1">
						

						<div class="form-group">
							<label>First Name</label>
							<input type="text" class="form-control <?php if(old('user_type_id') == 1): ?> <?php echo e($errors->has('first_name') ? ' is-invalid' : ''); ?>  <?php endif; ?>" name="first_name" value="<?php if(old('user_type_id') == 1): ?> <?php echo e(old('first_name')); ?> <?php endif; ?>" required autofocus>
							<i class="icon_mail_alt"></i>
							<?php if(old('user_type_id') == 1): ?>
							<?php if($errors->has('first_name')): ?>
		                        <span class="invalid-feedback" role="alert">
		                            <strong><?php echo e($errors->first('first_name')); ?></strong>
		                        </span>
		                    <?php endif; ?>
		                    <?php endif; ?>
						</div>

						<div class="form-group">
							<label>Last Name</label>
							<input type="text" class="form-control <?php if(old('user_type_id') == 1): ?> <?php echo e($errors->has('last_name') ? ' is-invalid' : ''); ?>  <?php endif; ?>" name="last_name" value="<?php if(old('user_type_id') == 1): ?> <?php echo e(old('last_name')); ?> <?php endif; ?>" required autofocus>
							<i class="icon_mail_alt"></i>
							<?php if(old('user_type_id') == 1): ?>
							<?php if($errors->has('last_name')): ?>
		                        <span class="invalid-feedback" role="alert">
		                            <strong><?php echo e($errors->first('last_name')); ?></strong>
		                        </span>
		                    <?php endif; ?>
		                    <?php endif; ?>
						</div>

						<div class="form-group">
							<label>Email</label>
							<input type="email" class="form-control <?php if(old('user_type_id') == 1): ?> <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>  <?php endif; ?>" name="email" value="<?php if(old('user_type_id') == 1): ?> <?php echo e(old('email')); ?> <?php endif; ?>" required autofocus>
							<i class="icon_mail_alt"></i>
							<?php if(old('user_type_id') == 1): ?>
							<?php if($errors->has('email')): ?>
		                        <span class="invalid-feedback" role="alert">
		                            <strong><?php echo e($errors->first('email')); ?></strong>
		                        </span>
		                    <?php endif; ?>
		                    <?php endif; ?>
						</div>
						<div class="form-group">
							<label>Password</label>
							<input type="password" class="form-control <?php if(old('user_type_id') == 1): ?> <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?> <?php endif; ?>" name="password" required>
							<i class="icon_lock_alt"></i>
							<?php if(old('user_type_id') == 1): ?>
							<?php if($errors->has('password')): ?>
		                        <span class="invalid-feedback" role="alert">
		                            <strong><?php echo e($errors->first('password')); ?></strong>
		                        </span>
		                    <?php endif; ?>
		                    <?php endif; ?>
						</div>

						<div class="form-group">
							<label>Confirm password</label>
							<input type="password" class="form-control <?php if(old('user_type_id') == 1): ?> <?php echo e($errors->has('password_confirmation') ? ' is-invalid' : ''); ?> <?php endif; ?>" name="password_confirmation" required>
							<i class="icon_lock_alt"></i>
							<?php if(old('user_type_id') == 1): ?>
							<?php if($errors->has('password_confirmation')): ?>
		                        <span class="invalid-feedback" role="alert">
		                            <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
		                        </span>
		                    <?php endif; ?>
		                    <?php endif; ?>
						</div>
						<div class="text-center"><input type="submit" value="Register" class="btn_1 full-width"></div>
						<div class="text-center mt-2">
							Have an account? <a href="#" onclick="switchLogin('login');">Login</a>
						</div>
					</form>
				</div>
			</div>

			<div class="sign-in-wrapper"  id="quickerLoginBlock">
			<form method="POST" action="<?php echo e(url('/servicer/login')); ?>">
				<?php echo csrf_field(); ?>
				<input type="hidden" name="user_type_id" value="2">
				<div class="form-group">
					<label>Email</label>
					<input type="email" class="form-control <?php if(old('user_type_id') == 2): ?> <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?> <?php endif; ?>" name="email" value="<?php if(old('user_type_id') == 2): ?>  <?php echo e(old('email')); ?> <?php endif; ?>" required autofocus>
					<i class="icon_mail_alt"></i>
					<?php if(old('user_type_id') == 2): ?>
					<?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                    <?php endif; ?>
				</div>
				<div class="form-group">
					<label>Password</label>
					<input type="password" class="form-control <?php if(old('user_type_id') == 2): ?> <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?> <?php endif; ?>" name="password" required>
					<i class="icon_lock_alt"></i>
					<?php if(old('user_type_id') == 2): ?>
					<?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                    <?php endif; ?>
				</div>
				<div class="clearfix add_bottom_15">
					<div class="checkboxes float-left">
						<label class="container_check">Remember me
						  <input class="form-check-input" type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
						  <span class="checkmark"></span>
						</label>
					</div>
					<div class="float-right mt-1"><label><a style="color: #999;" href="<?php echo e(url('servicer/password/reset')); ?>">Forgot Password?</a></label></div>
				</div>
				<div class="text-center"><input type="submit" value="Log In" class="btn_1 full-width"></div>
				<div class="text-center mt-2">
					Don’t have an account? <a href="<?php echo e(url('servicer/register')); ?>">Be a Quicker</a>
				</div>
			</form>
			</div>
		<!--form -->
	</div>
	<!-- /Sign In Popup -->


	<!--THIS IS MOST IMPORTANT PART OF QUOTE STEP FORM-->
	<!--quote steps modal start here // Here contain all logic of how to show diffrent form according to category-->
	

	<div class="modal quote-modal" id="getQuoteModal" data-keyboard="false" data-backdrop="static">
	  <div class="modal-dialog modal-lg modal-custom-lg">
	    <div class="modal-content quote-modal-block">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal">&times;</button>
	      </div>
	      <!-- Modal body 1-->
	      <div class="modal-body cutsom-scroll p-0">
	        <iframe id="quoteModalIframe" src="" style="width: 100%;height: calc(100vh - 210px)" frameborder="0"></iframe>
	      </div>
	    </div>
	  </div>
	</div>
	<!--quote steps modal start here-->
	<!--THIS IS MOST IMPORTANT PART OF QUOTE STEP FORM-->

	

	<!-- Custom SCRIPTS -->
	<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>

	<!-- scripts -->
	<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>