<?php $__env->startSection('title'); ?>
Quicker Reset Password | Quicker
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-class'); ?>
id="login_bg"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-class'); ?>
d-none
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<nav id="menu" class="fake_menu"></nav>
    
    <div id="login">
        <aside>
            <figure>
                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('assets/img/logo.png')); ?>" height="35" alt="" class="logo_sticky"></a>
            </figure>

                <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                    
                <form method="POST" action="<?php echo e(url('servicer/password/reset')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="user_type_id" value="2">
                <input type="hidden" name="token" value="<?php echo e($token); ?>">

                <div class="form-group">
                    <label>Email Address</label>
                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($email ?? old('email')); ?>" required autofocus>
                    <i class="icon_mail_alt"></i>

                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                    <i class="icon_lock_alt"></i>

                    <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                    <i class="icon_lock_alt"></i>
                </div>

                <input type="submit" class="btn_1 rounded full-width" name="login" value="Reset Password">
                <div class="text-center add_top_10">Already have an acccount? <strong><a href="<?php echo e(url('servicer/login')); ?>">Login</a></strong></div>
                <div class="text-center add_top_10"><strong><a href="<?php echo e(url('/')); ?>"><i class="icon-home"></i> Home</a></strong></div>
            </form>
            <div class="copy">© 2018 Quicker</div>
        </aside>
    </div>
    <!-- /login -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-class'); ?>
d-none
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>