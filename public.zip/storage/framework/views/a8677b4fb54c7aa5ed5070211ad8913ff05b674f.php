<?php $__env->startSection('title'); ?>
Dashboard | Quicker
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="sub_header_in sticky_header" style="margin-top: 0px;padding: 10px 0px;">
    <div class="container">
        <h4 style="font-size: 18px;" class="mb-0 text-b text-white">Dashboard</h4>
    </div>
    <!-- /container -->
</div>

<main>
    <div class="container mt-3">
        <div class="box_booking" style="min-height: 400px">
    </div>
</main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-class'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>