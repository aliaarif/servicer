@extends('layouts.master')

@section('title')
Dashboard | Quicker
@endsection

@section('body-class')

@endsection

@section('header-class')

@endsection

@section('content')
<div class="sub_header_in sticky_header" style="margin-top: 0px;padding: 10px 0px;">
    <div class="container">
        <h4 style="font-size: 18px;" class="mb-0 text-b text-white">Dashboard</h4>
    </div>
    <!-- /container -->
</div>

<main>
    <div class="container mt-3">
        <div class="box_booking" style="min-height: 400px">
    </div>
</main>

@endsection

@section('footer-class')

@endsection

@section('modal')

@endsection

@section('scripts')

@endsection

